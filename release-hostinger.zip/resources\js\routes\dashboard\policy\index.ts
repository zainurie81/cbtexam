import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardController::update
 * @see app/Http/Controllers/DashboardController.php:135
 * @route '/api/web/policies/{policy}/update'
 */
export const update = (args: { policy: string | number | { id: string | number } } | [policy: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/api/web/policies/{policy}/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardController::update
 * @see app/Http/Controllers/DashboardController.php:135
 * @route '/api/web/policies/{policy}/update'
 */
update.url = (args: { policy: string | number | { id: string | number } } | [policy: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { policy: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { policy: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    policy: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        policy: typeof args.policy === 'object'
                ? args.policy.id
                : args.policy,
                }

    return update.definition.url
            .replace('{policy}', parsedArgs.policy.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::update
 * @see app/Http/Controllers/DashboardController.php:135
 * @route '/api/web/policies/{policy}/update'
 */
update.post = (args: { policy: string | number | { id: string | number } } | [policy: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardController::update
 * @see app/Http/Controllers/DashboardController.php:135
 * @route '/api/web/policies/{policy}/update'
 */
    const updateForm = (args: { policy: string | number | { id: string | number } } | [policy: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardController::update
 * @see app/Http/Controllers/DashboardController.php:135
 * @route '/api/web/policies/{policy}/update'
 */
        updateForm.post = (args: { policy: string | number | { id: string | number } } | [policy: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, options),
            method: 'post',
        })
    
    update.form = updateForm
const policy = {
    update: Object.assign(update, update),
}

export default policy