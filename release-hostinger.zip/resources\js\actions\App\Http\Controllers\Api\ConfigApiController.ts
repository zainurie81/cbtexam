import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ConfigApiController::show
 * @see app/Http/Controllers/Api/ConfigApiController.php:15
 * @route '/api/config'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ConfigApiController::show
 * @see app/Http/Controllers/Api/ConfigApiController.php:15
 * @route '/api/config'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ConfigApiController::show
 * @see app/Http/Controllers/Api/ConfigApiController.php:15
 * @route '/api/config'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ConfigApiController::show
 * @see app/Http/Controllers/Api/ConfigApiController.php:15
 * @route '/api/config'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ConfigApiController::show
 * @see app/Http/Controllers/Api/ConfigApiController.php:15
 * @route '/api/config'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ConfigApiController::show
 * @see app/Http/Controllers/Api/ConfigApiController.php:15
 * @route '/api/config'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ConfigApiController::show
 * @see app/Http/Controllers/Api/ConfigApiController.php:15
 * @route '/api/config'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\ConfigApiController::checkUpdate
 * @see app/Http/Controllers/Api/ConfigApiController.php:28
 * @route '/api/config/check-update'
 */
export const checkUpdate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkUpdate.url(options),
    method: 'post',
})

checkUpdate.definition = {
    methods: ["post"],
    url: '/api/config/check-update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ConfigApiController::checkUpdate
 * @see app/Http/Controllers/Api/ConfigApiController.php:28
 * @route '/api/config/check-update'
 */
checkUpdate.url = (options?: RouteQueryOptions) => {
    return checkUpdate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ConfigApiController::checkUpdate
 * @see app/Http/Controllers/Api/ConfigApiController.php:28
 * @route '/api/config/check-update'
 */
checkUpdate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkUpdate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ConfigApiController::checkUpdate
 * @see app/Http/Controllers/Api/ConfigApiController.php:28
 * @route '/api/config/check-update'
 */
    const checkUpdateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkUpdate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ConfigApiController::checkUpdate
 * @see app/Http/Controllers/Api/ConfigApiController.php:28
 * @route '/api/config/check-update'
 */
        checkUpdateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkUpdate.url(options),
            method: 'post',
        })
    
    checkUpdate.form = checkUpdateForm
/**
* @see \App\Http\Controllers\Api\ConfigApiController::checkStatus
 * @see app/Http/Controllers/Api/ConfigApiController.php:53
 * @route '/api/config/status'
 */
export const checkStatus = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: checkStatus.url(options),
    method: 'get',
})

checkStatus.definition = {
    methods: ["get","head"],
    url: '/api/config/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ConfigApiController::checkStatus
 * @see app/Http/Controllers/Api/ConfigApiController.php:53
 * @route '/api/config/status'
 */
checkStatus.url = (options?: RouteQueryOptions) => {
    return checkStatus.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ConfigApiController::checkStatus
 * @see app/Http/Controllers/Api/ConfigApiController.php:53
 * @route '/api/config/status'
 */
checkStatus.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: checkStatus.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ConfigApiController::checkStatus
 * @see app/Http/Controllers/Api/ConfigApiController.php:53
 * @route '/api/config/status'
 */
checkStatus.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: checkStatus.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ConfigApiController::checkStatus
 * @see app/Http/Controllers/Api/ConfigApiController.php:53
 * @route '/api/config/status'
 */
    const checkStatusForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: checkStatus.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ConfigApiController::checkStatus
 * @see app/Http/Controllers/Api/ConfigApiController.php:53
 * @route '/api/config/status'
 */
        checkStatusForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: checkStatus.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ConfigApiController::checkStatus
 * @see app/Http/Controllers/Api/ConfigApiController.php:53
 * @route '/api/config/status'
 */
        checkStatusForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: checkStatus.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    checkStatus.form = checkStatusForm
const ConfigApiController = { show, checkUpdate, checkStatus }

export default ConfigApiController