import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\SessionApiController::start
 * @see app/Http/Controllers/Api/SessionApiController.php:19
 * @route '/api/session/start'
 */
export const start = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/api/session/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionApiController::start
 * @see app/Http/Controllers/Api/SessionApiController.php:19
 * @route '/api/session/start'
 */
start.url = (options?: RouteQueryOptions) => {
    return start.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionApiController::start
 * @see app/Http/Controllers/Api/SessionApiController.php:19
 * @route '/api/session/start'
 */
start.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\SessionApiController::start
 * @see app/Http/Controllers/Api/SessionApiController.php:19
 * @route '/api/session/start'
 */
    const startForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: start.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\SessionApiController::start
 * @see app/Http/Controllers/Api/SessionApiController.php:19
 * @route '/api/session/start'
 */
        startForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: start.url(options),
            method: 'post',
        })
    
    start.form = startForm
/**
* @see \App\Http\Controllers\Api\SessionApiController::heartbeat
 * @see app/Http/Controllers/Api/SessionApiController.php:81
 * @route '/api/session/{session}/heartbeat'
 */
export const heartbeat = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: heartbeat.url(args, options),
    method: 'post',
})

heartbeat.definition = {
    methods: ["post"],
    url: '/api/session/{session}/heartbeat',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionApiController::heartbeat
 * @see app/Http/Controllers/Api/SessionApiController.php:81
 * @route '/api/session/{session}/heartbeat'
 */
heartbeat.url = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { session: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { session: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    session: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        session: typeof args.session === 'object'
                ? args.session.id
                : args.session,
                }

    return heartbeat.definition.url
            .replace('{session}', parsedArgs.session.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionApiController::heartbeat
 * @see app/Http/Controllers/Api/SessionApiController.php:81
 * @route '/api/session/{session}/heartbeat'
 */
heartbeat.post = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: heartbeat.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\SessionApiController::heartbeat
 * @see app/Http/Controllers/Api/SessionApiController.php:81
 * @route '/api/session/{session}/heartbeat'
 */
    const heartbeatForm = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: heartbeat.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\SessionApiController::heartbeat
 * @see app/Http/Controllers/Api/SessionApiController.php:81
 * @route '/api/session/{session}/heartbeat'
 */
        heartbeatForm.post = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: heartbeat.url(args, options),
            method: 'post',
        })
    
    heartbeat.form = heartbeatForm
/**
* @see \App\Http\Controllers\Api\SessionApiController::log
 * @see app/Http/Controllers/Api/SessionApiController.php:122
 * @route '/api/session/{session}/log'
 */
export const log = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: log.url(args, options),
    method: 'post',
})

log.definition = {
    methods: ["post"],
    url: '/api/session/{session}/log',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionApiController::log
 * @see app/Http/Controllers/Api/SessionApiController.php:122
 * @route '/api/session/{session}/log'
 */
log.url = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { session: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { session: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    session: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        session: typeof args.session === 'object'
                ? args.session.id
                : args.session,
                }

    return log.definition.url
            .replace('{session}', parsedArgs.session.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionApiController::log
 * @see app/Http/Controllers/Api/SessionApiController.php:122
 * @route '/api/session/{session}/log'
 */
log.post = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: log.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\SessionApiController::log
 * @see app/Http/Controllers/Api/SessionApiController.php:122
 * @route '/api/session/{session}/log'
 */
    const logForm = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: log.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\SessionApiController::log
 * @see app/Http/Controllers/Api/SessionApiController.php:122
 * @route '/api/session/{session}/log'
 */
        logForm.post = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: log.url(args, options),
            method: 'post',
        })
    
    log.form = logForm
/**
* @see \App\Http\Controllers\Api\SessionApiController::violation
 * @see app/Http/Controllers/Api/SessionApiController.php:149
 * @route '/api/session/{session}/violation'
 */
export const violation = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: violation.url(args, options),
    method: 'post',
})

violation.definition = {
    methods: ["post"],
    url: '/api/session/{session}/violation',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionApiController::violation
 * @see app/Http/Controllers/Api/SessionApiController.php:149
 * @route '/api/session/{session}/violation'
 */
violation.url = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { session: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { session: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    session: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        session: typeof args.session === 'object'
                ? args.session.id
                : args.session,
                }

    return violation.definition.url
            .replace('{session}', parsedArgs.session.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionApiController::violation
 * @see app/Http/Controllers/Api/SessionApiController.php:149
 * @route '/api/session/{session}/violation'
 */
violation.post = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: violation.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\SessionApiController::violation
 * @see app/Http/Controllers/Api/SessionApiController.php:149
 * @route '/api/session/{session}/violation'
 */
    const violationForm = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: violation.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\SessionApiController::violation
 * @see app/Http/Controllers/Api/SessionApiController.php:149
 * @route '/api/session/{session}/violation'
 */
        violationForm.post = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: violation.url(args, options),
            method: 'post',
        })
    
    violation.form = violationForm
/**
* @see \App\Http\Controllers\Api\SessionApiController::submit
 * @see app/Http/Controllers/Api/SessionApiController.php:189
 * @route '/api/session/{session}/submit'
 */
export const submit = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/api/session/{session}/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionApiController::submit
 * @see app/Http/Controllers/Api/SessionApiController.php:189
 * @route '/api/session/{session}/submit'
 */
submit.url = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { session: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { session: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    session: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        session: typeof args.session === 'object'
                ? args.session.id
                : args.session,
                }

    return submit.definition.url
            .replace('{session}', parsedArgs.session.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionApiController::submit
 * @see app/Http/Controllers/Api/SessionApiController.php:189
 * @route '/api/session/{session}/submit'
 */
submit.post = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\SessionApiController::submit
 * @see app/Http/Controllers/Api/SessionApiController.php:189
 * @route '/api/session/{session}/submit'
 */
    const submitForm = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\SessionApiController::submit
 * @see app/Http/Controllers/Api/SessionApiController.php:189
 * @route '/api/session/{session}/submit'
 */
        submitForm.post = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(args, options),
            method: 'post',
        })
    
    submit.form = submitForm
const SessionApiController = { start, heartbeat, log, violation, submit }

export default SessionApiController