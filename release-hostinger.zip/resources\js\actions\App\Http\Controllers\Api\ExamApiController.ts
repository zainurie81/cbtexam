import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ExamApiController::index
 * @see app/Http/Controllers/Api/ExamApiController.php:15
 * @route '/api/exams'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/exams',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ExamApiController::index
 * @see app/Http/Controllers/Api/ExamApiController.php:15
 * @route '/api/exams'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ExamApiController::index
 * @see app/Http/Controllers/Api/ExamApiController.php:15
 * @route '/api/exams'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ExamApiController::index
 * @see app/Http/Controllers/Api/ExamApiController.php:15
 * @route '/api/exams'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ExamApiController::index
 * @see app/Http/Controllers/Api/ExamApiController.php:15
 * @route '/api/exams'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ExamApiController::index
 * @see app/Http/Controllers/Api/ExamApiController.php:15
 * @route '/api/exams'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ExamApiController::index
 * @see app/Http/Controllers/Api/ExamApiController.php:15
 * @route '/api/exams'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\ExamApiController::join
 * @see app/Http/Controllers/Api/ExamApiController.php:30
 * @route '/api/exams/join'
 */
export const join = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: join.url(options),
    method: 'post',
})

join.definition = {
    methods: ["post"],
    url: '/api/exams/join',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ExamApiController::join
 * @see app/Http/Controllers/Api/ExamApiController.php:30
 * @route '/api/exams/join'
 */
join.url = (options?: RouteQueryOptions) => {
    return join.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ExamApiController::join
 * @see app/Http/Controllers/Api/ExamApiController.php:30
 * @route '/api/exams/join'
 */
join.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: join.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ExamApiController::join
 * @see app/Http/Controllers/Api/ExamApiController.php:30
 * @route '/api/exams/join'
 */
    const joinForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: join.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ExamApiController::join
 * @see app/Http/Controllers/Api/ExamApiController.php:30
 * @route '/api/exams/join'
 */
        joinForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: join.url(options),
            method: 'post',
        })
    
    join.form = joinForm
const ExamApiController = { index, join }

export default ExamApiController