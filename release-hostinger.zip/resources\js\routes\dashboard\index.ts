import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import config8555dc from './config'
import policy from './policy'
/**
* @see \App\Http\Controllers\DashboardController::monitoring
 * @see app/Http/Controllers/DashboardController.php:41
 * @route '/dashboard/monitoring'
 */
export const monitoring = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: monitoring.url(options),
    method: 'get',
})

monitoring.definition = {
    methods: ["get","head"],
    url: '/dashboard/monitoring',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::monitoring
 * @see app/Http/Controllers/DashboardController.php:41
 * @route '/dashboard/monitoring'
 */
monitoring.url = (options?: RouteQueryOptions) => {
    return monitoring.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::monitoring
 * @see app/Http/Controllers/DashboardController.php:41
 * @route '/dashboard/monitoring'
 */
monitoring.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: monitoring.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::monitoring
 * @see app/Http/Controllers/DashboardController.php:41
 * @route '/dashboard/monitoring'
 */
monitoring.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: monitoring.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::monitoring
 * @see app/Http/Controllers/DashboardController.php:41
 * @route '/dashboard/monitoring'
 */
    const monitoringForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: monitoring.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::monitoring
 * @see app/Http/Controllers/DashboardController.php:41
 * @route '/dashboard/monitoring'
 */
        monitoringForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: monitoring.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::monitoring
 * @see app/Http/Controllers/DashboardController.php:41
 * @route '/dashboard/monitoring'
 */
        monitoringForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: monitoring.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    monitoring.form = monitoringForm
/**
* @see \App\Http\Controllers\DashboardController::devices
 * @see app/Http/Controllers/DashboardController.php:55
 * @route '/dashboard/devices'
 */
export const devices = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: devices.url(options),
    method: 'get',
})

devices.definition = {
    methods: ["get","head"],
    url: '/dashboard/devices',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::devices
 * @see app/Http/Controllers/DashboardController.php:55
 * @route '/dashboard/devices'
 */
devices.url = (options?: RouteQueryOptions) => {
    return devices.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::devices
 * @see app/Http/Controllers/DashboardController.php:55
 * @route '/dashboard/devices'
 */
devices.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: devices.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::devices
 * @see app/Http/Controllers/DashboardController.php:55
 * @route '/dashboard/devices'
 */
devices.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: devices.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::devices
 * @see app/Http/Controllers/DashboardController.php:55
 * @route '/dashboard/devices'
 */
    const devicesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: devices.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::devices
 * @see app/Http/Controllers/DashboardController.php:55
 * @route '/dashboard/devices'
 */
        devicesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: devices.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::devices
 * @see app/Http/Controllers/DashboardController.php:55
 * @route '/dashboard/devices'
 */
        devicesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: devices.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    devices.form = devicesForm
/**
* @see \App\Http\Controllers\DashboardController::config
 * @see app/Http/Controllers/DashboardController.php:67
 * @route '/dashboard/config'
 */
export const config = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: config.url(options),
    method: 'get',
})

config.definition = {
    methods: ["get","head"],
    url: '/dashboard/config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::config
 * @see app/Http/Controllers/DashboardController.php:67
 * @route '/dashboard/config'
 */
config.url = (options?: RouteQueryOptions) => {
    return config.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::config
 * @see app/Http/Controllers/DashboardController.php:67
 * @route '/dashboard/config'
 */
config.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: config.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::config
 * @see app/Http/Controllers/DashboardController.php:67
 * @route '/dashboard/config'
 */
config.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: config.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::config
 * @see app/Http/Controllers/DashboardController.php:67
 * @route '/dashboard/config'
 */
    const configForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: config.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::config
 * @see app/Http/Controllers/DashboardController.php:67
 * @route '/dashboard/config'
 */
        configForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: config.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::config
 * @see app/Http/Controllers/DashboardController.php:67
 * @route '/dashboard/config'
 */
        configForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: config.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    config.form = configForm
const dashboard = {
    monitoring: Object.assign(monitoring, monitoring),
devices: Object.assign(devices, devices),
config: Object.assign(config, config8555dc),
policy: Object.assign(policy, policy),
}

export default dashboard