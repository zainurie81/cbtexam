import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardController::update
 * @see app/Http/Controllers/DashboardController.php:110
 * @route '/api/web/config/update'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/api/web/config/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardController::update
 * @see app/Http/Controllers/DashboardController.php:110
 * @route '/api/web/config/update'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::update
 * @see app/Http/Controllers/DashboardController.php:110
 * @route '/api/web/config/update'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardController::update
 * @see app/Http/Controllers/DashboardController.php:110
 * @route '/api/web/config/update'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardController::update
 * @see app/Http/Controllers/DashboardController.php:110
 * @route '/api/web/config/update'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
const config = {
    update: Object.assign(update, update),
}

export default config