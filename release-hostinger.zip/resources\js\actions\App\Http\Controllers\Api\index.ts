import AuthApiController from './AuthApiController'
import ConfigApiController from './ConfigApiController'
import DeviceController from './DeviceController'
import ExamApiController from './ExamApiController'
import SessionApiController from './SessionApiController'
const Api = {
    AuthApiController: Object.assign(AuthApiController, AuthApiController),
ConfigApiController: Object.assign(ConfigApiController, ConfigApiController),
DeviceController: Object.assign(DeviceController, DeviceController),
ExamApiController: Object.assign(ExamApiController, ExamApiController),
SessionApiController: Object.assign(SessionApiController, SessionApiController),
}

export default Api