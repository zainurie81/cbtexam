import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DeviceController::register
 * @see app/Http/Controllers/Api/DeviceController.php:15
 * @route '/api/device/register'
 */
export const register = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/api/device/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\DeviceController::register
 * @see app/Http/Controllers/Api/DeviceController.php:15
 * @route '/api/device/register'
 */
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DeviceController::register
 * @see app/Http/Controllers/Api/DeviceController.php:15
 * @route '/api/device/register'
 */
register.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\DeviceController::register
 * @see app/Http/Controllers/Api/DeviceController.php:15
 * @route '/api/device/register'
 */
    const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: register.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DeviceController::register
 * @see app/Http/Controllers/Api/DeviceController.php:15
 * @route '/api/device/register'
 */
        registerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: register.url(options),
            method: 'post',
        })
    
    register.form = registerForm
/**
* @see \App\Http\Controllers\Api\DeviceController::show
 * @see app/Http/Controllers/Api/DeviceController.php:48
 * @route '/api/device/{deviceId}'
 */
export const show = (args: { deviceId: string | number } | [deviceId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/device/{deviceId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DeviceController::show
 * @see app/Http/Controllers/Api/DeviceController.php:48
 * @route '/api/device/{deviceId}'
 */
show.url = (args: { deviceId: string | number } | [deviceId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deviceId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    deviceId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        deviceId: args.deviceId,
                }

    return show.definition.url
            .replace('{deviceId}', parsedArgs.deviceId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DeviceController::show
 * @see app/Http/Controllers/Api/DeviceController.php:48
 * @route '/api/device/{deviceId}'
 */
show.get = (args: { deviceId: string | number } | [deviceId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DeviceController::show
 * @see app/Http/Controllers/Api/DeviceController.php:48
 * @route '/api/device/{deviceId}'
 */
show.head = (args: { deviceId: string | number } | [deviceId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DeviceController::show
 * @see app/Http/Controllers/Api/DeviceController.php:48
 * @route '/api/device/{deviceId}'
 */
    const showForm = (args: { deviceId: string | number } | [deviceId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DeviceController::show
 * @see app/Http/Controllers/Api/DeviceController.php:48
 * @route '/api/device/{deviceId}'
 */
        showForm.get = (args: { deviceId: string | number } | [deviceId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DeviceController::show
 * @see app/Http/Controllers/Api/DeviceController.php:48
 * @route '/api/device/{deviceId}'
 */
        showForm.head = (args: { deviceId: string | number } | [deviceId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const DeviceController = { register, show }

export default DeviceController