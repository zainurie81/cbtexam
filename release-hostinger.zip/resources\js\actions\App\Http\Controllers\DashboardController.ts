import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardController::index
 * @see app/Http/Controllers/DashboardController.php:23
 * @route '/dashboard'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::index
 * @see app/Http/Controllers/DashboardController.php:23
 * @route '/dashboard'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::index
 * @see app/Http/Controllers/DashboardController.php:23
 * @route '/dashboard'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::index
 * @see app/Http/Controllers/DashboardController.php:23
 * @route '/dashboard'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::index
 * @see app/Http/Controllers/DashboardController.php:23
 * @route '/dashboard'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::index
 * @see app/Http/Controllers/DashboardController.php:23
 * @route '/dashboard'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::index
 * @see app/Http/Controllers/DashboardController.php:23
 * @route '/dashboard'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DashboardController::monitoring
 * @see app/Http/Controllers/DashboardController.php:41
 * @route '/dashboard/monitoring'
 */
export const monitoring = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: monitoring.url(options),
    method: 'get',
})

monitoring.definition = {
    methods: ["get","head"],
    url: '/dashboard/monitoring',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::monitoring
 * @see app/Http/Controllers/DashboardController.php:41
 * @route '/dashboard/monitoring'
 */
monitoring.url = (options?: RouteQueryOptions) => {
    return monitoring.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::monitoring
 * @see app/Http/Controllers/DashboardController.php:41
 * @route '/dashboard/monitoring'
 */
monitoring.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: monitoring.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::monitoring
 * @see app/Http/Controllers/DashboardController.php:41
 * @route '/dashboard/monitoring'
 */
monitoring.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: monitoring.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::monitoring
 * @see app/Http/Controllers/DashboardController.php:41
 * @route '/dashboard/monitoring'
 */
    const monitoringForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: monitoring.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::monitoring
 * @see app/Http/Controllers/DashboardController.php:41
 * @route '/dashboard/monitoring'
 */
        monitoringForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: monitoring.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::monitoring
 * @see app/Http/Controllers/DashboardController.php:41
 * @route '/dashboard/monitoring'
 */
        monitoringForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: monitoring.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    monitoring.form = monitoringForm
/**
* @see \App\Http\Controllers\DashboardController::devices
 * @see app/Http/Controllers/DashboardController.php:55
 * @route '/dashboard/devices'
 */
export const devices = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: devices.url(options),
    method: 'get',
})

devices.definition = {
    methods: ["get","head"],
    url: '/dashboard/devices',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::devices
 * @see app/Http/Controllers/DashboardController.php:55
 * @route '/dashboard/devices'
 */
devices.url = (options?: RouteQueryOptions) => {
    return devices.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::devices
 * @see app/Http/Controllers/DashboardController.php:55
 * @route '/dashboard/devices'
 */
devices.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: devices.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::devices
 * @see app/Http/Controllers/DashboardController.php:55
 * @route '/dashboard/devices'
 */
devices.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: devices.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::devices
 * @see app/Http/Controllers/DashboardController.php:55
 * @route '/dashboard/devices'
 */
    const devicesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: devices.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::devices
 * @see app/Http/Controllers/DashboardController.php:55
 * @route '/dashboard/devices'
 */
        devicesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: devices.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::devices
 * @see app/Http/Controllers/DashboardController.php:55
 * @route '/dashboard/devices'
 */
        devicesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: devices.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    devices.form = devicesForm
/**
* @see \App\Http\Controllers\DashboardController::config
 * @see app/Http/Controllers/DashboardController.php:67
 * @route '/dashboard/config'
 */
export const config = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: config.url(options),
    method: 'get',
})

config.definition = {
    methods: ["get","head"],
    url: '/dashboard/config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::config
 * @see app/Http/Controllers/DashboardController.php:67
 * @route '/dashboard/config'
 */
config.url = (options?: RouteQueryOptions) => {
    return config.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::config
 * @see app/Http/Controllers/DashboardController.php:67
 * @route '/dashboard/config'
 */
config.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: config.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::config
 * @see app/Http/Controllers/DashboardController.php:67
 * @route '/dashboard/config'
 */
config.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: config.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::config
 * @see app/Http/Controllers/DashboardController.php:67
 * @route '/dashboard/config'
 */
    const configForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: config.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::config
 * @see app/Http/Controllers/DashboardController.php:67
 * @route '/dashboard/config'
 */
        configForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: config.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::config
 * @see app/Http/Controllers/DashboardController.php:67
 * @route '/dashboard/config'
 */
        configForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: config.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    config.form = configForm
/**
* @see \App\Http\Controllers\DashboardController::toggleDeviceLock
 * @see app/Http/Controllers/DashboardController.php:151
 * @route '/api/web/devices/{device}/toggle-lock'
 */
export const toggleDeviceLock = (args: { device: string | number | { id: string | number } } | [device: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleDeviceLock.url(args, options),
    method: 'post',
})

toggleDeviceLock.definition = {
    methods: ["post"],
    url: '/api/web/devices/{device}/toggle-lock',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardController::toggleDeviceLock
 * @see app/Http/Controllers/DashboardController.php:151
 * @route '/api/web/devices/{device}/toggle-lock'
 */
toggleDeviceLock.url = (args: { device: string | number | { id: string | number } } | [device: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { device: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { device: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    device: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        device: typeof args.device === 'object'
                ? args.device.id
                : args.device,
                }

    return toggleDeviceLock.definition.url
            .replace('{device}', parsedArgs.device.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::toggleDeviceLock
 * @see app/Http/Controllers/DashboardController.php:151
 * @route '/api/web/devices/{device}/toggle-lock'
 */
toggleDeviceLock.post = (args: { device: string | number | { id: string | number } } | [device: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleDeviceLock.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardController::toggleDeviceLock
 * @see app/Http/Controllers/DashboardController.php:151
 * @route '/api/web/devices/{device}/toggle-lock'
 */
    const toggleDeviceLockForm = (args: { device: string | number | { id: string | number } } | [device: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleDeviceLock.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardController::toggleDeviceLock
 * @see app/Http/Controllers/DashboardController.php:151
 * @route '/api/web/devices/{device}/toggle-lock'
 */
        toggleDeviceLockForm.post = (args: { device: string | number | { id: string | number } } | [device: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleDeviceLock.url(args, options),
            method: 'post',
        })
    
    toggleDeviceLock.form = toggleDeviceLockForm
/**
* @see \App\Http\Controllers\DashboardController::kickSession
 * @see app/Http/Controllers/DashboardController.php:178
 * @route '/api/web/sessions/{session}/kick'
 */
export const kickSession = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: kickSession.url(args, options),
    method: 'post',
})

kickSession.definition = {
    methods: ["post"],
    url: '/api/web/sessions/{session}/kick',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardController::kickSession
 * @see app/Http/Controllers/DashboardController.php:178
 * @route '/api/web/sessions/{session}/kick'
 */
kickSession.url = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { session: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { session: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    session: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        session: typeof args.session === 'object'
                ? args.session.id
                : args.session,
                }

    return kickSession.definition.url
            .replace('{session}', parsedArgs.session.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::kickSession
 * @see app/Http/Controllers/DashboardController.php:178
 * @route '/api/web/sessions/{session}/kick'
 */
kickSession.post = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: kickSession.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardController::kickSession
 * @see app/Http/Controllers/DashboardController.php:178
 * @route '/api/web/sessions/{session}/kick'
 */
    const kickSessionForm = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: kickSession.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardController::kickSession
 * @see app/Http/Controllers/DashboardController.php:178
 * @route '/api/web/sessions/{session}/kick'
 */
        kickSessionForm.post = (args: { session: string | number | { id: string | number } } | [session: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: kickSession.url(args, options),
            method: 'post',
        })
    
    kickSession.form = kickSessionForm
/**
* @see \App\Http\Controllers\DashboardController::updateConfig
 * @see app/Http/Controllers/DashboardController.php:110
 * @route '/api/web/config/update'
 */
export const updateConfig = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateConfig.url(options),
    method: 'post',
})

updateConfig.definition = {
    methods: ["post"],
    url: '/api/web/config/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardController::updateConfig
 * @see app/Http/Controllers/DashboardController.php:110
 * @route '/api/web/config/update'
 */
updateConfig.url = (options?: RouteQueryOptions) => {
    return updateConfig.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::updateConfig
 * @see app/Http/Controllers/DashboardController.php:110
 * @route '/api/web/config/update'
 */
updateConfig.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateConfig.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardController::updateConfig
 * @see app/Http/Controllers/DashboardController.php:110
 * @route '/api/web/config/update'
 */
    const updateConfigForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateConfig.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardController::updateConfig
 * @see app/Http/Controllers/DashboardController.php:110
 * @route '/api/web/config/update'
 */
        updateConfigForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateConfig.url(options),
            method: 'post',
        })
    
    updateConfig.form = updateConfigForm
/**
* @see \App\Http\Controllers\DashboardController::updatePolicy
 * @see app/Http/Controllers/DashboardController.php:135
 * @route '/api/web/policies/{policy}/update'
 */
export const updatePolicy = (args: { policy: string | number | { id: string | number } } | [policy: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updatePolicy.url(args, options),
    method: 'post',
})

updatePolicy.definition = {
    methods: ["post"],
    url: '/api/web/policies/{policy}/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DashboardController::updatePolicy
 * @see app/Http/Controllers/DashboardController.php:135
 * @route '/api/web/policies/{policy}/update'
 */
updatePolicy.url = (args: { policy: string | number | { id: string | number } } | [policy: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { policy: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { policy: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    policy: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        policy: typeof args.policy === 'object'
                ? args.policy.id
                : args.policy,
                }

    return updatePolicy.definition.url
            .replace('{policy}', parsedArgs.policy.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::updatePolicy
 * @see app/Http/Controllers/DashboardController.php:135
 * @route '/api/web/policies/{policy}/update'
 */
updatePolicy.post = (args: { policy: string | number | { id: string | number } } | [policy: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updatePolicy.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DashboardController::updatePolicy
 * @see app/Http/Controllers/DashboardController.php:135
 * @route '/api/web/policies/{policy}/update'
 */
    const updatePolicyForm = (args: { policy: string | number | { id: string | number } } | [policy: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePolicy.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DashboardController::updatePolicy
 * @see app/Http/Controllers/DashboardController.php:135
 * @route '/api/web/policies/{policy}/update'
 */
        updatePolicyForm.post = (args: { policy: string | number | { id: string | number } } | [policy: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePolicy.url(args, options),
            method: 'post',
        })
    
    updatePolicy.form = updatePolicyForm
const DashboardController = { index, monitoring, devices, config, toggleDeviceLock, kickSession, updateConfig, updatePolicy }

export default DashboardController